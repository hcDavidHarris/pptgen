# AI Routing Table

This bundle contains a machine-readable routing table for AI-assisted pptgen workflows.

Files:
- `routing_table.yaml` — recommended source of truth
- `routing_table.json` — optional machine-friendly equivalent

Recommended repo location:

```text
pptgen/
└─ docs/
   └─ ai-playbooks/
      ├─ README.md
      ├─ routing_table.yaml
      └─ routing_table.json
```

Purpose:
- help Claude and other agents choose the right playbook
- map input types to example patterns and output targets
- make workflow selection deterministic and automatable
