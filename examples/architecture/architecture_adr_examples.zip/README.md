# Architecture / ADR Example Library for pptgen

This library contains example YAML decks for common architecture and ADR (Architecture Decision Record) presentations.

Suggested repo location:

pptgen/
└─ examples/
   └─ architecture/

Files included:

- adr_template.yaml
- architecture_review.yaml
- platform_architecture.yaml
- system_context.yaml
- technology_selection.yaml
